import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from wsgiref import simple_server
from flask import Flask, request
from flask import Response
import os
from flask_cors import CORS, cross_origin


os.putenv('LANG', 'en_US.UTF-8')
os.putenv('LC_ALL', 'en_US.UTF-8')

app = Flask(__name__)
CORS(app)



@app.route("/sendmail", methods=['POST'])
@cross_origin()
def sendEmailCOVID():
    try:
        if request.json['emailid'] is not None:

            toaddr = request.json['emailid']  ## email id of the user
            contact_add = "gaur***********@gmail.com"  ## the email id of the support team
            fromaddr = "gaur**********@gmail.com"   ## the email id from where we are going to send the course syllabus to user. (ngrok app as Local Server) amil ID
            mobile_number = request.json['mobile_number']
            name = request.json['name']




## Send Course Syllabus  E-Mail  to User

            # instance of MIMEMultipart       # whenever our Email has multiple parts (From, To, SubjectLine etc) in it to add those parts to the Mail
            msg = MIMEMultipart()       # function to access multiple parts of mail

            # storing the senders email address
            msg['From'] = fromaddr

            # storing the receivers email address
            msg['To'] = ",".join(toaddr)
            # msg['To'] = toaddr

            # storing the subject
            msg['Subject'] = "COVID_Helper Email"

            # string to store the body of the mail
            body = " Hello there. " \
                   "Grretings of the Day!! " \
                   "I have a Message for you that this Email will contain attachment that you required. Please find it." \
                   " Thank you. Have a great Day." \
                   "BR//" \
                   "ChatBot" \
                   " Developed by" \
                   " Gaurav Patil"

            # attach the body with the msg instance
            msg.attach(MIMEText(body, 'plain'))

            # open the file to be sent   # Syllabus file .cdv/ .pdf/ .txt
            filename = "COVID19_FAQ.pdf"
            attachment = open(filename, "rb")

            # instance of MIMEBase and named as p
            p = MIMEBase('application', 'octet-stream')

            # To change the payload into encoded form
            p.set_payload((attachment).read())

            # encode into base64
            encoders.encode_base64(p)

            p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

            # attach the instance 'p' to instance 'msg'
            msg.attach(p)

            # creates SMTP session  # login to SMTP server
            s = smtplib.SMTP('smtp.gmail.com', 587)

            # start TLS for security
            s.starttls()

            # Authentication   # account and password,  from where we are going to sent Course syllabus to user.
            s.login(fromaddr,"**************") # give your password here,    # also for this to work , u have to change this mail seeting to "access permitted to less secure Apps"

            # Converts the Multipart msg into a string
            text = msg.as_string()
            # sending the mail  # contains 'From' person address and 'To' address and text body of mail
            s.sendmail(fromaddr, toaddr, text)





            # send mail with username , mobile number and email id to Concerned Support Team

            # instance of MIMEMultipart
            msg1 = MIMEMultipart()
            # storing the subject
            msg1['Subject'] = " Hi support team you have a Query For Course Details"

            # string to store the body of the mail
            # to format your text in Mail Body use   +"\t " + for tab  and    +"\n " +  for new line below
            body1 = (" Hello there. \n" 
                   "Grretings of the Day!! " 
                    "Person with name {0} have some queries regarding Corona Virus details."
                   "Please reach to {0} at his mobile number {1} and email id {2}  if you have to ask him for user experience".format(name,mobile_number,toaddr))   # 0=name, 1=MobileNo, 2=email
            'BR//'
            'AI ChatBot'
            ' Developed by'
            ' Gaurav Patil'

# attach the body with the msg instance
            msg1.attach(MIMEText(body1, 'plain'))

            text = msg1.as_string()
            # sending the mail
            s.sendmail(fromaddr, contact_add, text)

            # terminating the session
            s.quit()

            return Response("CORONA Virus details has been sent to the mail id %s" % toaddr +"\n " +
                            "Please find it. ")

    except ValueError:
        return Response("Error Occurred! %s" %ValueError)
    except KeyError:
        return Response("Error Occurred! %s" %KeyError)
    except Exception as e:
        return Response("Error Occurred! %s" %e)

#port = int(os.getenv("PORT"))
if __name__ == "__main__":
    app.run(debug=True)
# #    host = '0.0.0.0'
# #    port = 5000
#     httpd = simple_server.make_server(host, port, app)
#     print("Try to hit http://localhost:5000/sendmail this url in Postman to validate your app    Serving on %s %d" % (host, port))
#     httpd.serve_forever()
