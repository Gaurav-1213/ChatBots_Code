# Covid-19
Covid-19 DashBoard of India statewise




Deployed Dashboards on Heroku,
https://evening-depths-68859.herokuapp.com/



This is the experience that I am sharing with you about how I built AI chatBots in Amazon Lex and Googles DialogFlow. These two chatBots will help you for finding Live CORONA Virus cases in your respective state, as well as it will show you all the required information about CORONA Virus like its symptoms and preventive measures n all.
So hope you will like this 😊 and experience my ChatBots at 👉 https://www.facebook.com/ChatBot_Info-105074211172004/?modal=admin_todo_tour



